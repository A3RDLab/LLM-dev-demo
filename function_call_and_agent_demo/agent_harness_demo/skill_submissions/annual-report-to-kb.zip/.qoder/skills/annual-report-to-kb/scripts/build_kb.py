#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
年报 PDF → 知识库 参考实现（annual-report-to-kb skill）。

按年报内置目录（目录页文本）将 PDF 切分为章节，逐级存储为 Markdown；
剔除附件（审计报告/财务报表及附注）；导出嵌入图片并生成识别文件模板与 manifest。

用法:
  python build_kb.py <out_dir> <pdf> <目录名> <文档标签> [<pdf> <目录名> <文档标签> ...]

示例:
  python build_kb.py knowledge_base "report.pdf" "工商银行-2025年度报告" "中国工商银行2025年度报告（A股）"

依赖: pymupdf（建议 venv 安装）
"""
import json
import os
import re
import sys
from pathlib import Path

import pymupdf

# 目录条目：编号单独一行或编号与标题同行，标题 + 点线 + 页码结尾
TOC_ENTRY_RE = re.compile(r"^(\d+(?:\.\d+)*)\.?\s*(.+?)\s*\.{3,}\s*(\d+)\s*$", re.M)
CJK = r"一-鿿　-〿＀-￯，。、；：“”‘’（）"
CJK_SPACE_RE = re.compile(rf"(?<=[{CJK}]) (?=[{CJK}])")
# 页眉过滤：含“股份有限公司…年度报告”的短行（A 股年报页眉形如“XX股份有限公司2025 年度报告（A 股）”）；
# 注意不能只匹配“年度报告”，否则会误伤“…关于2025 年度报告的确认意见”等正文标题
HEADER_RE = re.compile(r"股份有限公司\s*\d{4}\s*年度报告")


def parse_toc(doc):
    """在前 12 页中寻找目录页并解析条目，返回 [(level, number, title, printed_page)]"""
    toc_pages = []
    for i in range(2, min(doc.page_count, 12)):
        text = doc[i].get_text()
        if "目录" in text and TOC_ENTRY_RE.search(text):
            toc_pages.append(i)
    entries = []
    for i in toc_pages:
        for m in TOC_ENTRY_RE.finditer(doc[i].get_text()):
            num, title, page = m.group(1), m.group(2).strip(), int(m.group(3))
            level = num.count(".") + 1
            entries.append({"level": level, "num": num, "title": title, "printed": page})
    return entries


def find_page_offset(doc, entries):
    """用第一个目录条目定位 印刷页码 -> PDF页码 的偏移量（跳过目录页本身）"""
    e = entries[0]
    probe = re.compile(rf"{re.escape(e['num'])}[.\s]*{re.escape(e['title'][:4])}")
    for i in range(5, min(doc.page_count, 30)):  # 目录页及之前不算正文
        if probe.search(doc[i].get_text()):
            return i + 1 - e["printed"]
    raise RuntimeError(f"无法定位偏移量: {e}")


def verify_entries(doc, entries, offset):
    """校验各条目标题是否出现在对应页（正文标题格式如 8.3.1 公司金融业务），返回异常条目列表"""
    bad = []
    for e in entries:
        idx = e["printed"] + offset - 1
        if idx >= doc.page_count:
            bad.append((e, "超出文档页数"))
            continue
        title = e["title"].replace(" ", "")
        page_text = re.sub(r"\s+", "", doc[idx].get_text())
        probe = f"{e['num']}{title[:6]}"
        if probe not in page_text and title[:6] not in page_text:
            bad.append((e, f"PDF第{idx + 1}页未找到标题"))
    return bad


def find_appendix_start(doc, from_idx):
    """在正文之后寻找附件封面页（含“附件”标题 + 股票代码 + 年报字样且内容很短），
    返回 0-based 页号；未找到返回 None"""
    for i in range(from_idx, doc.page_count):
        t = re.sub(r"\s+", "", doc[i].get_text())
        if len(t) < 200 and "附件" in t and "股票代码" in t and "年度报告" in t:
            return i
    return None


def clean_text(s):
    s = s.replace("　", " ")
    prev = None
    while prev != s:  # 去掉 CJK 字符之间的空格
        prev = s
        s = CJK_SPACE_RE.sub("", s)
    s = re.sub(r"[ \t]+\n", "\n", s)
    return s.strip()


def md_table(rows):
    rows = [["" if c is None else str(c).replace("|", "\\|").replace("\n", "<br>").strip() for c in r] for r in rows]
    if not rows:
        return ""
    ncol = max(len(r) for r in rows)
    rows = [r + [""] * (ncol - len(r)) for r in rows]
    out = ["| " + " | ".join(rows[0]) + " |", "|" + "---|" * ncol]
    for r in rows[1:]:
        out.append("| " + " | ".join(r) + " |")
    return "\n".join(out)


NUM_CELL_RE = re.compile(r"^[\d,，.（）()%％\-—]+$")


def split_cells(spans, gap=6.0):
    """按 span 之间的水平间隙把一行切分为单元格 [(x0, x1, text)]"""
    cells = []
    for x0, x1, text, _size in spans:
        if not text.strip():
            continue
        if cells and x0 - cells[-1][1] > gap:
            cells.append([x0, x1, text.strip()])
        elif cells:
            cells[-1][1] = x1
            cells[-1][2] += text.strip()
        else:
            cells.append([x0, x1, text.strip()])
    return [tuple(c) for c in cells if c[2]]


def cell_key(cell):
    """数字单元格按右边缘对齐、文字按左边缘对齐，作为列聚类特征"""
    return cell[1] if NUM_CELL_RE.match(cell[2]) else cell[0]


def cluster_columns(rows_cells, tol=10.0):
    """把多行单元格的对齐边聚类为列中心，返回排序后的列中心列表"""
    centers = []
    for row in rows_cells:
        for cell in row:
            k = cell_key(cell)
            for i, c in enumerate(centers):
                if abs(k - c) <= tol:
                    centers[i] = (c + k) / 2
                    break
            else:
                centers.append(k)
    return sorted(centers)


def rows_to_table(rows_cells):
    """根据列聚类把单元格行重建为二维表（含换行单元格的续行合并）"""
    cols = cluster_columns(rows_cells)
    if len(cols) < 3:
        return None

    def to_grid(rows):
        grid = []
        for row in rows:
            line = [""] * len(cols)
            for cell in row:
                k = cell_key(cell)
                idx = min(range(len(cols)), key=lambda i: abs(cols[i] - k))
                line[idx] = (line[idx] + " " + cell[2]).strip() if line[idx] else cell[2]
            grid.append(line)
        return grid

    # 续行启发式：数字单元格不足 2 个的行视为上一行换行单元格的延续，按列合并
    rows = [list(r) for r in rows_cells]
    merged_rows = [rows[0]]
    for row in rows[1:]:
        nnum = sum(1 for _x0, _x1, t in row if NUM_CELL_RE.match(t))
        if nnum < 2 and merged_rows:
            prev = merged_rows[-1]
            combined = sorted(prev + row, key=lambda c: c[0])
            # 合并后同一列区间不应出现两个都有内容的单元格，否则不是续行
            ok = True
            for a in prev:
                for b in row:
                    if a[2] and b[2] and abs(a[0] - b[0]) <= 12:
                        ok = False
            if ok:
                merged_rows[-1] = combined
                continue
        merged_rows.append(row)
    grid = to_grid(merged_rows)
    grid = [[r[i] for i in range(len(cols)) if any(g[i] for g in grid)] for r in grid]  # 剔除全空列
    # 至少两行且过半行含 2 个以上数字型单元格才算表格
    num_ok = sum(1 for r in grid if sum(1 for c in r if NUM_CELL_RE.match(c)) >= 2)
    if len(grid) < 2 or num_ok < len(grid) / 2:
        return None
    return grid


def is_header_line(text):
    """页眉/页码过滤"""
    return (HEADER_RE.search(text) and len(text) < 60) or re.fullmatch(r"\d{1,3}", text) is not None


def extract_page_md(page, extra_items=None):
    """把一页转为 Markdown：有线表格用 find_tables；无边框表格按列坐标聚类重建；正文按段合并；
    extra_items 为按页面位置插入的其他元素 [(y, x, md)]（如图片引用）"""
    try:
        lined = page.find_tables()
    except Exception:
        lined = []
    tbboxes = [t.bbox for t in lined]
    items = []  # (y, x, md)
    if extra_items:
        items.extend(extra_items)
    for t in lined:
        md = md_table(t.extract())
        if md:
            items.append((t.bbox[1], t.bbox[0], md))

    lines = []
    for b in page.get_text("dict")["blocks"]:
        if b["type"] != 0:
            continue
        for l in b["lines"]:
            spans = [(s["bbox"][0], s["bbox"][2], s["text"], s["size"]) for s in l["spans"]]
            text = "".join(s[2] for s in spans).strip()
            if not text or is_header_line(text):
                continue
            y0, x0, y1 = l["bbox"][1], l["bbox"][0], l["bbox"][3]
            cx = (l["bbox"][0] + l["bbox"][2]) / 2
            cy = (y0 + y1) / 2
            if any(tb[0] <= cx <= tb[2] and tb[1] <= cy <= tb[3] for tb in tbboxes):
                continue
            lines.append({"y0": y0, "y1": y1, "x0": x0,
                          "spans": spans, "text": clean_text(text)})
    lines.sort(key=lambda it: it["y0"])

    if not lines:
        return "\n\n".join(it[2] for it in sorted(items))
    lh = sorted(l["y1"] - l["y0"] for l in lines)[len(lines) // 2]

    # 合并 y 坐标略有偏差的同一视觉行（表格单元格常各自成行）
    merged = []
    for l in lines:
        if merged:
            g = merged[-1]
            gy = (g["y0"] + g["y1"]) / 2
            if abs((l["y0"] + l["y1"]) / 2 - gy) < 0.5 * lh:
                g["y0"], g["y1"] = min(g["y0"], l["y0"]), max(g["y1"], l["y1"])
                g["x0"] = min(g["x0"], l["x0"])
                g["spans"].extend(l["spans"])
                continue
        merged.append({"y0": l["y0"], "y1": l["y1"], "x0": l["x0"],
                       "spans": list(l["spans"]), "text": l["text"]})
    for g in merged:
        g["spans"].sort(key=lambda s: s[0])
        g["cells"] = split_cells(g["spans"])
        g["text"] = clean_text("".join(s[2] for s in g["spans"]))
        # 单元格之间存在大间隙 → 疑似多列文本表（如释义表），不并入正文段；
        # 但首格为章节编号的行（如 8.2.1 利润表项目分析）仍按标题行拼接
        g["split"] = any(b[0] - a[1] > 15 for a, b in zip(g["cells"], g["cells"][1:]))
        if g["split"]:
            first = g["cells"][0][2]
            if re.fullmatch(r"\d+(?:\.\d+)*[、.]?", first):
                g["split"] = False
                g["text"] = " ".join(c[2] for c in g["cells"])
            else:
                g["text"] = " | ".join(c[2] for c in g["cells"])
    lines = merged

    def is_table_row(l):
        return len(l["cells"]) >= 3 and sum(1 for _x0, _x1, t in l["cells"] if NUM_CELL_RE.match(t)) >= 2

    i = 0
    while i < len(lines):
        l = lines[i]
        if is_table_row(l):  # 收集连续的表格行并重建（含换行单元格产生的文字续行）
            run = [l]
            j = i + 1
            while j < len(lines) and lines[j]["y0"] - lines[j - 1]["y1"] < 1.6 * lh and \
                    (is_table_row(lines[j]) or len(lines[j]["cells"]) < 3):
                run.append(lines[j])
                j += 1
            while run and not is_table_row(run[-1]):  # 去掉末尾的文字续行残留
                j -= 1
                run.pop()
            grid = rows_to_table([r["cells"] for r in run]) if len(run) >= 2 else None
            if grid:
                items.append((run[0]["y0"], run[0]["x0"], md_table(grid)))
                i = j
                continue
        # 正文段合并：行距小则拼入同一段；首行缩进/间距变大/多列文本行则分段
        para = [l["text"]]
        j = i + 1
        while j < len(lines) and not is_table_row(lines[j]) and not lines[j]["split"] \
                and lines[j]["y0"] - lines[j - 1]["y1"] <= 1.0 * lh:
            para.append(lines[j]["text"])
            j += 1
        items.append((l["y0"], l["x0"], "".join(para)))
        i = j

    items.sort(key=lambda it: (round(it[0], 1), it[1]))
    return "\n\n".join(it[2] for it in items if it[2])


def extract_section_md(doc, e, sample, page_images, rel_assets):
    """提取单个章节为 Markdown，按页面位置插入图片及其识别文件引用"""
    parts = []
    for idx in range(e["start"], e["end"] + 1):
        refs = []
        for info in page_images.get(idx, []):
            b = info["bbox"]
            refs.append((b[1], b[0],
                         f"![]({rel_assets}/{info['name']})\n\n"
                         f"> 图表识别结果：[{info['stem']}.md]({rel_assets}/{info['stem']}.md)"))
        t = extract_page_md(doc[idx], refs)
        if t:
            parts.append(t)
    meta = (f"# {e['num']} {e['title']}\n\n"
            f"> 来源：`{sample['file']}` · {sample['label']} · "
            f"印刷页 P{e['printed']}–P{e['printed'] + e['end'] - e['start']} · "
            f"PDF 页 {e['start'] + 1}–{e['end'] + 1}\n\n")
    return meta + "\n\n".join(parts) + "\n"


def padded_num(num):
    return ".".join(p.zfill(2) for p in num.split("."))


def safe_name(s):
    return re.sub(r'[\\/:*?"<>|\s]+', "", s)


def build_doc(sample, out_root: Path):
    src = Path(sample["file"]).expanduser()
    doc = pymupdf.open(src)
    entries = parse_toc(doc)
    if not entries:
        raise RuntimeError(f"{src} 未解析到目录")
    offset = find_page_offset(doc, entries)
    bad = verify_entries(doc, entries, offset)
    print(f"[{sample['name']}] 页数={doc.page_count} 目录条目={len(entries)} 页码偏移={offset} 校验异常={len(bad)}")
    for e, why in bad:
        print(f"    ! {e['num']} {e['title']} -> {why}")

    # 计算每个条目的页码区间 [start, end]（PDF 页，0-based）
    for i, e in enumerate(entries):
        e["start"] = e["printed"] + offset - 1
        e["end"] = (entries[i + 1]["printed"] + offset - 2) if i + 1 < len(entries) else doc.page_count - 1

    # 附件不入库：把目录末条目截断到附件封面页之前
    appendix_start = find_appendix_start(doc, entries[-1]["start"])
    if appendix_start is not None and appendix_start - 1 < entries[-1]["end"]:
        entries[-1]["end"] = appendix_start - 1
        print(f"    附件边界：PDF 页 {appendix_start + 1} 为附件封面，正文止于 PDF 页 {appendix_start}，"
              f"附件 {doc.page_count - appendix_start} 页不入库")
    else:
        print("    未发现附件封面页，末章延伸到文档末尾")
    body_end = entries[-1]["end"]

    doc_dir = out_root / sample["name"]
    doc_dir.mkdir(parents=True, exist_ok=True)

    # 采集并导出正文范围内的嵌入图片（最短边 >= 300px，过滤二维码等小图）
    assets_dir = doc_dir / "assets"
    assets_dir.mkdir(exist_ok=True)
    page_images, manifest = {}, []
    for idx in range(body_end + 1):
        seq = 0
        # get_images 提供 xref，get_image_info 提供页面位置，按尺寸配对
        xrefs = [(t[0], t[2], t[3]) for t in doc[idx].get_images(full=True)]
        for info in doc[idx].get_image_info():
            if min(info["width"], info["height"]) < 300:
                continue
            xref = next((x for x, w, h in xrefs if w == info["width"] and h == info["height"]), None)
            if xref is None:
                continue
            xrefs = [(x, w, h) for x, w, h in xrefs if x != xref]
            seq += 1
            stem = f"img_p{idx + 1}_{seq}"
            raw = doc.extract_image(xref)
            (assets_dir / f"{stem}.{raw['ext']}").write_bytes(raw["image"])
            page_images.setdefault(idx, []).append(
                {"name": f"{stem}.{raw['ext']}", "stem": stem, "bbox": info["bbox"]})
            owner = next((x for x in reversed(entries) if x["start"] <= idx <= x["end"]), None)
            manifest.append({"file": f"{stem}.{raw['ext']}", "page_pdf": idx + 1,
                             "size_px": [info["width"], info["height"]],
                             "bbox": [round(v, 1) for v in info["bbox"]],
                             "section": f"{owner['num']} {owner['title']}" if owner else None})
            rec = assets_dir / f"{stem}.md"  # 识别文件已存在则不覆盖（保护已填充内容）
            if not rec.exists():
                rec.write_text(
                    f"# 图表识别：{stem}.{raw['ext']}\n\n"
                    f"> 图片：`{stem}.{raw['ext']}` · 来源：`{sample['file']}` PDF 页 {idx + 1} · "
                    f"章节：{owner['num']} {owner['title'] if owner else '未知'}\n\n"
                    f"## 类型\n\n待识别\n\n## 结构化内容\n\n（待填充）\n\n## 说明\n\n（待填充）\n",
                    encoding="utf-8")
    (assets_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"    导出图片 {len(manifest)} 张 -> {assets_dir}")

    dirs = {1: doc_dir}  # level -> 当前目录

    index_lines = [f"# {sample['label']} · 知识库索引\n",
                   f"> 来源文件：`{sample['file']}`（共 {doc.page_count} 页） · 章节数：{len(entries)}\n"]
    for e in entries:
        empty = e["start"] > e["end"]
        fname = f"{padded_num(e['num'])}-{safe_name(e['title'])}.md"
        if e["level"] == 1:
            if empty:  # 父章节无独立内容，建目录容纳子节
                d = doc_dir / f"{padded_num(e['num'])}-{safe_name(e['title'])}"
                d.mkdir(parents=True, exist_ok=True)
                dirs = {1: d}
                e["_rel"] = None
            else:
                d = doc_dir
                has_children = any(x["num"].startswith(e["num"] + ".") for x in entries)
                if has_children:
                    d = doc_dir / f"{padded_num(e['num'])}-{safe_name(e['title'])}"
                    d.mkdir(parents=True, exist_ok=True)
                    dirs = {1: d}
                rel_assets = os.path.relpath(assets_dir, d)
                (d / fname).write_text(
                    extract_section_md(doc, e, sample, page_images, rel_assets), encoding="utf-8")
                e["_rel"] = f"{d.relative_to(doc_dir) / fname}" if d != doc_dir else fname
        else:
            parent = dirs.get(e["level"] - 1, doc_dir)
            has_children = any(x["num"].startswith(e["num"] + ".") for x in entries)
            if has_children:
                d = parent / f"{padded_num(e['num'])}-{safe_name(e['title'])}"
                d.mkdir(parents=True, exist_ok=True)
                dirs[e["level"]] = d
                target_dir = d
            else:
                target_dir = parent
            if not empty:
                rel_assets = os.path.relpath(assets_dir, target_dir)
                (target_dir / fname).write_text(
                    extract_section_md(doc, e, sample, page_images, rel_assets), encoding="utf-8")
                e["_rel"] = str((target_dir / fname).relative_to(doc_dir))
            else:
                e["_rel"] = None
        indent = "    " * (e["level"] - 1)
        rng = f"P{e['printed']}–P{e['printed'] + e['end'] - e['start']}" if not empty else f"P{e['printed']}"
        if e["_rel"]:
            index_lines.append(f"{indent}- {e['num']} [{e['title']}]({e['_rel']})（{rng}）")
        else:
            index_lines.append(f"{indent}- **{e['num']} {e['title']}**（{rng}）")
    if appendix_start is not None:
        index_lines.append(f"\n> 附件（PDF 页 {appendix_start + 1}–{doc.page_count}，含审计报告、"
                           f"财务报表及附注、未经审计补充资料等）未纳入本知识库。")
    (doc_dir / "index.md").write_text("\n".join(index_lines) + "\n", encoding="utf-8")
    npages = doc.page_count
    doc.close()
    return {"name": sample["name"], "label": sample["label"], "file": sample["file"],
            "pages": npages, "sections": len(entries), "images": len(manifest)}


def main():
    args = sys.argv[1:]
    if len(args) < 4 or (len(args) - 1) % 3 != 0:
        print("用法: python build_kb.py <out_dir> <pdf> <目录名> <文档标签> [<pdf> <目录名> <文档标签> ...]")
        sys.exit(1)
    out_root = Path(args[0])
    out_root.mkdir(parents=True, exist_ok=True)
    samples = [{"file": args[i], "name": args[i + 1], "label": args[i + 2]}
               for i in range(1, len(args), 3)]
    docs = [build_doc(s, out_root) for s in samples]
    lines = ["# 知识库索引", "", "本知识库由年报 PDF 按内置目录逐级切分生成，每个章节为一个 Markdown 文件；"
             "嵌入图片导出至各文档 assets/ 目录，图片旁附同名识别文件（图表结构化内容见识别文件）。", "",
             "| 文档 | 来源文件 | 章节数 | 图片数 | 入口 |", "|---|---|---|---|---|"]
    for d in docs:
        lines.append(f"| {d['label']} | `{d['file']}` | {d['sections']} | {d['images']} | "
                     f"[{d['name']}/index.md]({d['name']}/index.md) |")
    (out_root / "index.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"\n完成，输出目录: {out_root}")


if __name__ == "__main__":
    main()
